Sample README.txt

We collectively worked on reciever.cpp and sender.cpp

Eventually your report about how you implemented thread synchronization
in the server should go here
