Team member: Hanbei Zhou, Zhihan Xia
We collectively worked on the three function uint256_create_from_u64, uint256_create, and uint256_get_bits.