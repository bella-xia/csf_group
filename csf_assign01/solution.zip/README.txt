Team member: Hanbei Zhou, Zhihan Xia
We collectively worked on the three Functions uint256_create_from_u64, uint256_create, and uint256_get_bits.
We collectively worked on the five functions uint256_create_from_hex, uint256_format_as_hex, uint256_add, 
uint256_sub, and uint256_mul. Zhihan implemented the test for add, sub, and mul; Hanbei implemented
the test for create_from_hex and format_as_hex.