Team members: Hanbei Zhou, Bella Xia

We collectively worked on Makefile.